package it.samu.mollier

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf<Stato?>(null) }
    val curves by produceState<List<Curve>?>(null) {
        value = withContext(Dispatchers.Default) { MollierData.build() }
    }
    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Calcolatore") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Diagramma") })
        }
        if (tab == 0) {
            Calculator(result, onResult = { result = it }, onShow = { tab = 1 })
        } else {
            val c = curves
            if (c == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                DiagramScreen(c, result)
            }
        }
    }
}

// ───────────────────────────── Calcolatore ─────────────────────────────

@Composable
fun Calculator(result: Stato?, onResult: (Stato?) -> Unit, onShow: () -> Unit) {
    var mode by remember { mutableIntStateOf(0) }
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val modes = listOf("T, p", "h, s", "T, x", "p, x")
    val labels = listOf(
        listOf("T [°C]", "p [bar]"),
        listOf("h [kJ/kg]", "s [kJ/(kg·K)]"),
        listOf("T [°C]", "x [0–1]"),
        listOf("p [bar]", "x [0–1]")
    )

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Acqua/vapore – diagramma di Mollier (h–s)", style = MaterialTheme.typography.titleMedium)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            modes.forEachIndexed { i, m ->
                FilterChip(
                    selected = mode == i,
                    onClick = { mode = i; a = ""; b = ""; error = null; onResult(null) },
                    label = { Text(m) }
                )
            }
        }
        OutlinedTextField(
            value = a, onValueChange = { a = it }, label = { Text(labels[mode][0]) }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = b, onValueChange = { b = it }, label = { Text(labels[mode][1]) }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()
        )
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val x = a.replace(',', '.').toDoubleOrNull()
                val y = b.replace(',', '.').toDoubleOrNull()
                if (x == null || y == null) {
                    error = "Inserisci due valori numerici"; onResult(null)
                } else {
                    try {
                        val r = when (mode) {
                            0 -> If97.fromTP(x + 273.15, y / 10.0)
                            1 -> If97.fromHS(x, y)
                            2 -> If97.fromTx(x + 273.15, y)
                            else -> If97.fromPx(x / 10.0, y)
                        }
                        error = null; onResult(r)
                    } catch (e: Exception) {
                        error = e.message ?: "Valori non validi"; onResult(null)
                    }
                }
            }
        ) { Text("Calcola") }

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        result?.let { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(r.phase, style = MaterialTheme.typography.titleSmall)
                    ResultRow("T", "%.2f °C  (%.2f K)".format(r.T - 273.15, r.T))
                    ResultRow("p", "%.4f bar".format(r.p * 10.0))
                    ResultRow("h", "%.2f kJ/kg".format(r.h))
                    ResultRow("s", "%.4f kJ/(kg·K)".format(r.s))
                    ResultRow("v", "%.6f m³/kg".format(r.v))
                    ResultRow("x", r.x?.let { "%.4f".format(it) } ?: "–")
                }
            }
            OutlinedButton(onClick = onShow, modifier = Modifier.fillMaxWidth()) { Text("Mostra sul diagramma") }
        }
        Text(
            "Modello IAPWS-IF97 (Regioni 1, 2, 4). Campo: 0–350 °C per la saturazione, vapore fino a 800 °C. " +
                "La Regione 3 (zona critica) non è inclusa.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun ResultRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.bodyMedium)
        Text(v, style = MaterialTheme.typography.bodyMedium)
    }
}

// ───────────────────────────── Diagramma ─────────────────────────────

private fun niceStep(range: Double): Double {
    val raw = range / 6.0
    val mag = 10.0.pow(floor(log10(raw)))
    val f = raw / mag
    val n = if (f < 1.5) 1.0 else if (f < 3.5) 2.0 else if (f < 7.5) 5.0 else 10.0
    return n * mag
}

@Composable
fun DiagramScreen(curves: List<Curve>, point: Stato?) {
    var view by remember { mutableStateOf(MollierData.DEFAULT_VIEW) }
    var tap by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var msg by remember { mutableStateOf("Trascina, pizzica per lo zoom, tocca per leggere i valori") }
    val tm = rememberTextMeasurer()

    Box(Modifier.fillMaxSize()) {
        Canvas(
            Modifier.fillMaxSize().clipToBounds()
                .pointerInput(Unit) {
                    detectTransformGestures { c, pan, zoom, _ ->
                        val v = view
                        val w = size.width.toDouble(); val ht = size.height.toDouble()
                        val fx = c.x.toDouble() / w; val fy = c.y.toDouble() / ht
                        val sC = v.sMin + fx * (v.sMax - v.sMin)
                        val hC = v.hMax - fy * (v.hMax - v.hMin)
                        val z = zoom.toDouble()
                        val ns = ((v.sMax - v.sMin) / z).coerceIn(0.3, 14.0)
                        val nh = ((v.hMax - v.hMin) / z).coerceIn(100.0, 5500.0)
                        val sMin = sC - fx * ns - pan.x.toDouble() / w * ns
                        val hMax = hC + fy * nh + pan.y.toDouble() / ht * nh
                        view = Viewport(sMin, sMin + ns, hMax - nh, hMax)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { o ->
                        val v = view
                        val s = v.sMin + o.x.toDouble() / size.width * (v.sMax - v.sMin)
                        val h = v.hMax - o.y.toDouble() / size.height * (v.hMax - v.hMin)
                        tap = s to h
                        msg = try {
                            val r = If97.fromHS(h, s)
                            "%s\nT = %.1f °C   p = %.3f bar\nh = %.0f kJ/kg   s = %.3f kJ/(kg·K)%s".format(
                                r.phase, r.T - 273.15, r.p * 10.0, r.h, r.s,
                                r.x?.let { "   x = %.3f".format(it) } ?: ""
                            )
                        } catch (e: Exception) {
                            "h = %.0f kJ/kg   s = %.3f kJ/(kg·K)\nFuori dal campo (liquido o zona critica)".format(h, s)
                        }
                    }
                }
        ) {
            drawChart(view, curves, point, tap, tm)
        }

        Surface(
            Modifier.align(Alignment.TopCenter).padding(8.dp),
            shape = RoundedCornerShape(10.dp), tonalElevation = 4.dp, shadowElevation = 2.dp
        ) { Text(msg, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 12.sp) }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(onClick = { view = MollierData.DEFAULT_VIEW }) { Text("Reset") }
            if (point != null) {
                FilledTonalButton(onClick = {
                    view = Viewport(point.s - 1.0, point.s + 1.0, point.h - 450.0, point.h + 450.0)
                }) { Text("Vai al punto") }
            }
        }
    }
}

private fun DrawScope.drawChart(
    v: Viewport, curves: List<Curve>, point: Stato?, tap: Pair<Double, Double>?, tm: TextMeasurer
) {
    val w = size.width; val ht = size.height
    fun sx(s: Double) = ((s - v.sMin) / (v.sMax - v.sMin) * w).toFloat()
    fun hy(h: Double) = ((v.hMax - h) / (v.hMax - v.hMin) * ht).toFloat()

    drawRect(Color.White)
    val grid = Color(0xFFE0E0E0)
    val axisText = TextStyle(fontSize = 10.sp, color = Color(0xFF616161))

    // griglia + etichette assi
    val ds = niceStep(v.sMax - v.sMin)
    var s = ceil(v.sMin / ds) * ds
    while (s <= v.sMax) {
        drawLine(grid, Offset(sx(s), 0f), Offset(sx(s), ht), 1f)
        drawText(tm, "%.4g".format(s), Offset(sx(s) + 3f, ht - 16.dp.toPx()), axisText)
        s += ds
    }
    val dh = niceStep(v.hMax - v.hMin)
    var h = ceil(v.hMin / dh) * dh
    while (h <= v.hMax) {
        drawLine(grid, Offset(0f, hy(h)), Offset(w, hy(h)), 1f)
        drawText(tm, "%.0f".format(h), Offset(3f, hy(h) - 14.dp.toPx()), axisText)
        h += dh
    }
    drawText(tm, "s [kJ/kgK]", Offset(w - 62.dp.toPx(), ht - 32.dp.toPx()), axisText)
    drawText(tm, "h [kJ/kg]", Offset(30.dp.toPx(), 4.dp.toPx() + 64.dp.toPx()), axisText)

    // curve
    for (c in curves) {
        val col: Color; val sw: Float
        when (c.kind) {
            Kind.DOME -> { col = Color.Black; sw = 3.dp.toPx() }
            Kind.XLINE -> { col = Color(0xFF6A8CAF); sw = 1.dp.toPx() }
            Kind.ISOBAR -> { col = Color(0xFF1565C0); sw = 1.5.dp.toPx() }
            Kind.ISOTHERM -> { col = Color(0xFFC62828); sw = 1.5.dp.toPx() }
        }
        val path = Path()
        for (i in c.s.indices) {
            val x = sx(c.s[i]); val y = hy(c.h[i])
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, col, style = Stroke(width = sw))
        if (c.label != null && c.labelIdx >= 0) {
            val x = sx(c.s[c.labelIdx]); val y = hy(c.h[c.labelIdx])
            if (x in 0f..w && y in 0f..ht) {
                drawText(tm, c.label, Offset(x + 2f, y - 13.dp.toPx()), TextStyle(fontSize = 10.sp, color = col))
            }
        }
    }

    // punto calcolato e punto toccato
    if (point != null) {
        val c = Offset(sx(point.s), hy(point.h))
        drawCircle(Color.White, 9.dp.toPx(), c)
        drawCircle(Color(0xFF2E7D32), 6.dp.toPx(), c)
    }
    if (tap != null) {
        val c = Offset(sx(tap.first), hy(tap.second))
        val r = 8.dp.toPx()
        drawLine(Color(0xFFEF6C00), Offset(c.x - r, c.y), Offset(c.x + r, c.y), 2.dp.toPx())
        drawLine(Color(0xFFEF6C00), Offset(c.x, c.y - r), Offset(c.x, c.y + r), 2.dp.toPx())
    }
}
