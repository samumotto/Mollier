package it.samu.mollier

import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

/** Stato termodinamico. h [kJ/kg], s [kJ/kgK], v [m3/kg], T [K], p [MPa], x titolo (null se non bifase). */
data class Stato(
    val T: Double, val p: Double, val h: Double, val s: Double, val v: Double,
    val x: Double?, val phase: String
)

/**
 * Proprietà dell'acqua secondo IAPWS-IF97, Regioni 1 (liquido), 2 (vapore) e 4 (saturazione).
 * Validità: 273.15 K <= T <= 623.15 K per la saturazione; vapore surriscaldato fino a 1073.15 K.
 * La Regione 3 (vicinanze del punto critico, T > 623.15 K con liquido) NON è inclusa.
 */
object If97 {
    const val R = 0.461526
    const val T_MIN = 273.16
    const val T_SAT_MAX = 623.15
    const val T_MAX = 1073.15
    const val P_MIN = 0.0006
    const val P_SAT_MAX = 16.529 // psat(623.15 K)

    private val R1 = arrayOf(
        doubleArrayOf(0.0, -2.0, 0.14632971213167), doubleArrayOf(0.0, -1.0, -0.84548187169114),
        doubleArrayOf(0.0, 0.0, -0.37563603672040e1), doubleArrayOf(0.0, 1.0, 0.33855169168385e1),
        doubleArrayOf(0.0, 2.0, -0.95791963387872), doubleArrayOf(0.0, 3.0, 0.15772038513228),
        doubleArrayOf(0.0, 4.0, -0.16616417199501e-1), doubleArrayOf(0.0, 5.0, 0.81214629983568e-3),
        doubleArrayOf(1.0, -9.0, 0.28319080123804e-3), doubleArrayOf(1.0, -7.0, -0.60706301565874e-3),
        doubleArrayOf(1.0, -1.0, -0.18990068218419e-1), doubleArrayOf(1.0, 0.0, -0.32529748770505e-1),
        doubleArrayOf(1.0, 1.0, -0.21841717175414e-1), doubleArrayOf(1.0, 3.0, -0.52838357969930e-4),
        doubleArrayOf(2.0, -3.0, -0.47184321073267e-3), doubleArrayOf(2.0, 0.0, -0.30001780793026e-3),
        doubleArrayOf(2.0, 1.0, 0.47661393906987e-4), doubleArrayOf(2.0, 3.0, -0.44141845330846e-5),
        doubleArrayOf(2.0, 17.0, -0.72694996297594e-15), doubleArrayOf(3.0, -4.0, -0.31679644845054e-4),
        doubleArrayOf(3.0, 0.0, -0.28270797985312e-5), doubleArrayOf(3.0, 6.0, -0.85205128120103e-9),
        doubleArrayOf(4.0, -5.0, -0.22425281908000e-5), doubleArrayOf(4.0, -2.0, -0.65171222895601e-6),
        doubleArrayOf(4.0, 10.0, -0.14341729937924e-12), doubleArrayOf(5.0, -8.0, -0.40516996860117e-6),
        doubleArrayOf(8.0, -11.0, -0.12734301741641e-8), doubleArrayOf(8.0, -6.0, -0.17424871230634e-9),
        doubleArrayOf(21.0, -29.0, -0.68762131295531e-18), doubleArrayOf(23.0, -31.0, 0.14478307828521e-19),
        doubleArrayOf(29.0, -38.0, 0.26335781662795e-22), doubleArrayOf(30.0, -39.0, -0.11947622640071e-22),
        doubleArrayOf(31.0, -40.0, 0.18228094581404e-23), doubleArrayOf(32.0, -41.0, -0.93537087292458e-25)
    )
    private val J0 = arrayOf(
        doubleArrayOf(0.0, -0.96927686500217e1), doubleArrayOf(1.0, 0.10086655968018e2),
        doubleArrayOf(-5.0, -0.56087911283020e-2), doubleArrayOf(-4.0, 0.71452738081455e-1),
        doubleArrayOf(-3.0, -0.40710498223928), doubleArrayOf(-2.0, 0.14240819171444e1),
        doubleArrayOf(-1.0, -0.43839511319450e1), doubleArrayOf(2.0, -0.28408632460772),
        doubleArrayOf(3.0, 0.21268463753307e-1)
    )
    private val R2 = arrayOf(
        doubleArrayOf(1.0, 0.0, -0.17731742473213e-2), doubleArrayOf(1.0, 1.0, -0.17834862292358e-1),
        doubleArrayOf(1.0, 2.0, -0.45996013696365e-1), doubleArrayOf(1.0, 3.0, -0.57581259083432e-1),
        doubleArrayOf(1.0, 6.0, -0.50325278727930e-1), doubleArrayOf(2.0, 1.0, -0.33032641670203e-4),
        doubleArrayOf(2.0, 2.0, -0.18948987516315e-3), doubleArrayOf(2.0, 4.0, -0.39392777243355e-2),
        doubleArrayOf(2.0, 7.0, -0.43797295650573e-1), doubleArrayOf(2.0, 36.0, -0.26674547914087e-4),
        doubleArrayOf(3.0, 0.0, 0.20481737692309e-7), doubleArrayOf(3.0, 1.0, 0.43870667284435e-6),
        doubleArrayOf(3.0, 3.0, -0.32277677238570e-4), doubleArrayOf(3.0, 6.0, -0.15033924542148e-2),
        doubleArrayOf(3.0, 35.0, -0.40668253562649e-1), doubleArrayOf(4.0, 1.0, -0.78847309559367e-9),
        doubleArrayOf(4.0, 2.0, 0.12790717852285e-7), doubleArrayOf(4.0, 3.0, 0.48225372718507e-6),
        doubleArrayOf(5.0, 7.0, 0.22922076337661e-5), doubleArrayOf(6.0, 3.0, -0.16714766451061e-10),
        doubleArrayOf(6.0, 16.0, -0.21171472321355e-2), doubleArrayOf(6.0, 35.0, -0.23895741934104e2),
        doubleArrayOf(7.0, 0.0, -0.59059564324270e-17), doubleArrayOf(7.0, 11.0, -0.12621808899101e-5),
        doubleArrayOf(7.0, 25.0, -0.38946842435739e-1), doubleArrayOf(8.0, 8.0, 0.11256211360459e-10),
        doubleArrayOf(8.0, 36.0, -0.82311340897998e1), doubleArrayOf(9.0, 13.0, 0.19809712802088e-7),
        doubleArrayOf(10.0, 4.0, 0.10406965210174e-18), doubleArrayOf(10.0, 10.0, -0.10234747095929e-12),
        doubleArrayOf(10.0, 14.0, -0.10018179379511e-8), doubleArrayOf(16.0, 29.0, -0.80882908646985e-10),
        doubleArrayOf(16.0, 50.0, 0.10693031879409), doubleArrayOf(18.0, 57.0, -0.33662250574171),
        doubleArrayOf(20.0, 20.0, 0.89185845355421e-24), doubleArrayOf(20.0, 35.0, 0.30629316876232e-12),
        doubleArrayOf(20.0, 48.0, -0.42002467698208e-5), doubleArrayOf(21.0, 21.0, -0.59056029685639e-25),
        doubleArrayOf(22.0, 53.0, 0.37826947613457e-5), doubleArrayOf(23.0, 39.0, -0.12768608934681e-14),
        doubleArrayOf(24.0, 26.0, 0.73087610595061e-28), doubleArrayOf(24.0, 40.0, 0.55414715350778e-16),
        doubleArrayOf(24.0, 58.0, -0.94369707241210e-6)
    )
    private val N4 = doubleArrayOf(
        0.11670521452767e4, -0.72421316703206e6, -0.17073846940092e2, 0.12020824702470e5,
        -0.32325550322333e7, 0.14915108613530e2, -0.48232657361591e4, 0.40511340542057e6,
        -0.23855557567849, 0.65017534844798e3
    )

    /** Regione 1, liquido. Ritorna [v, h, s]. */
    fun region1(T: Double, p: Double): DoubleArray {
        val pi = p / 16.53; val tau = 1386.0 / T
        val a = 7.1 - pi; val b = tau - 1.222
        var g = 0.0; var gp = 0.0; var gt = 0.0
        for (c in R1) {
            val i = c[0]; val j = c[1]; val n = c[2]
            g += n * a.pow(i) * b.pow(j)
            gp += -n * i * a.pow(i - 1) * b.pow(j)
            gt += n * j * a.pow(i) * b.pow(j - 1)
        }
        return doubleArrayOf(R * T / (p * 1000) * pi * gp, R * T * tau * gt, R * (tau * gt - g))
    }

    /** Regione 2, vapore. Ritorna [v, h, s]. */
    fun region2(T: Double, p: Double): DoubleArray {
        val tau = 540.0 / T; val b = tau - 0.5
        var g0 = ln(p); var g0t = 0.0
        for (c in J0) { g0 += c[1] * tau.pow(c[0]); g0t += c[1] * c[0] * tau.pow(c[0] - 1) }
        var gr = 0.0; var grp = 0.0; var grt = 0.0
        for (c in R2) {
            val i = c[0]; val j = c[1]; val n = c[2]
            gr += n * p.pow(i) * b.pow(j)
            grp += n * i * p.pow(i - 1) * b.pow(j)
            grt += n * p.pow(i) * j * b.pow(j - 1)
        }
        return doubleArrayOf(
            R * T / (p * 1000) * (1 + p * grp),
            R * T * tau * (g0t + grt),
            R * (tau * (g0t + grt) - (g0 + gr))
        )
    }

    /** Pressione di saturazione [MPa] a T [K]. */
    fun pSat(T: Double): Double {
        val th = T + N4[8] / (T - N4[9])
        val a = th * th + N4[0] * th + N4[1]
        val b = N4[2] * th * th + N4[3] * th + N4[4]
        val c = N4[5] * th * th + N4[6] * th + N4[7]
        return (2 * c / (-b + sqrt(b * b - 4 * a * c))).pow(4)
    }

    /** Temperatura di saturazione [K] a p [MPa]. */
    fun tSat(p: Double): Double {
        val be = p.pow(0.25)
        val e = be * be + N4[2] * be + N4[5]
        val f = N4[0] * be * be + N4[3] * be + N4[6]
        val g = N4[1] * be * be + N4[4] * be + N4[7]
        val d = 2 * g / (-f - sqrt(f * f - 4 * e * g))
        return (N4[9] + d - sqrt((N4[9] + d) * (N4[9] + d) - 4 * (N4[8] + N4[9] * d))) / 2
    }

    /** Pressione [MPa] del confine B23 a T [K]. */
    private fun pB23(T: Double) = 348.05185628969 - 1.1671859879975 * T + 1.0192970039326e-3 * T * T

    /** Proprietà di saturazione a T: [pSat, vf, hf, sf, vg, hg, sg]. */
    fun sat(T: Double): DoubleArray {
        val p = pSat(T)
        val f = region1(T, p); val g = region2(T, p)
        return doubleArrayOf(p, f[0], f[1], f[2], g[0], g[1], g[2])
    }

    private fun ok(cond: Boolean, msg: String) { if (!cond) throw IllegalArgumentException(msg) }

    /** Stato da T [K] e p [MPa] (liquido sottoraffreddato o vapore surriscaldato). */
    fun fromTP(T: Double, p: Double): Stato {
        ok(T in 273.15..T_MAX, "T fuori campo (0–800 °C)")
        ok(p in P_MIN..100.0, "p fuori campo (0.0006–100 MPa)")
        if (T <= T_SAT_MAX) {
            val ps = pSat(T)
            if (kotlin.math.abs(p - ps) / ps < 1e-6) throw IllegalArgumentException("Sulla curva di saturazione: usa la modalità T–x o p–x")
            val r = if (p > ps) region1(T, p) else region2(T, p)
            return Stato(T, p, r[1], r[2], r[0], null, if (p > ps) "Liquido sottoraffreddato" else "Vapore surriscaldato")
        }
        ok(p <= pB23(T), "Zona liquido/supercritica oltre 350 °C (Regione 3) non supportata")
        val r = region2(T, p)
        return Stato(T, p, r[1], r[2], r[0], null, "Vapore surriscaldato")
    }

    /** Stato bifase da T [K] e titolo x. */
    fun fromTx(T: Double, x: Double): Stato {
        ok(T in T_MIN..T_SAT_MAX, "T di saturazione supportata: 0.01–350 °C")
        ok(x in 0.0..1.0, "Il titolo x deve essere tra 0 e 1")
        val q = sat(T)
        return Stato(T, q[0], q[2] + x * (q[5] - q[2]), q[3] + x * (q[6] - q[3]), q[1] + x * (q[4] - q[1]), x, phase(x))
    }

    fun fromPx(p: Double, x: Double): Stato {
        ok(p in P_MIN..P_SAT_MAX, "p di saturazione supportata: 0.0006–16.5 MPa")
        return fromTx(tSat(p), x)
    }

    private fun phase(x: Double) = when {
        x <= 0.0 -> "Liquido saturo"; x >= 1.0 -> "Vapore saturo secco"; else -> "Miscela liquido–vapore"
    }

    /** Stato da entalpia h [kJ/kg] ed entropia s [kJ/kgK]. */
    fun fromHS(h: Double, s: Double): Stato {
        // 1) zona bifase: cerca T tale che il titolo da s e da h coincidano
        fun diff(T: Double): Double {
            val q = sat(T)
            return (s - q[3]) / (q[6] - q[3]) - (h - q[2]) / (q[5] - q[2])
        }
        var lo = T_MIN; var hi = T_SAT_MAX
        val dlo = diff(lo); val dhi = diff(hi)
        if (dlo * dhi <= 0) {
            repeat(60) { val m = 0.5 * (lo + hi); if (diff(lo) * diff(m) <= 0) hi = m else lo = m }
            val T = 0.5 * (lo + hi); val q = sat(T)
            val x = (h - q[2]) / (q[5] - q[2])
            if (x in -1e-9..1 + 1e-9) {
                val xc = x.coerceIn(0.0, 1.0)
                return Stato(T, q[0], h, s, q[1] + xc * (q[4] - q[1]), xc, phase(xc))
            }
        }
        // 2) vapore surriscaldato: bisezione annidata (T da s a p fissata, poi p da h)
        // codici: -1 = s sotto la curva del vapore saturo (p troppo bassa), -2 = oltre T_MAX (p troppo alta)
        fun tFromPS(p: Double): Double {
            var a = tSatOrMin(p); var b = T_MAX
            if (s < region2(a, p)[2]) return -1.0
            if (s > region2(b, p)[2]) return -2.0
            repeat(60) { val m = 0.5 * (a + b); if (region2(m, p)[2] < s) a = m else b = m }
            return 0.5 * (a + b)
        }
        fun hAt(p: Double): Double {
            val T = tFromPS(p)
            return when { T == -1.0 -> Double.NEGATIVE_INFINITY; T == -2.0 -> Double.POSITIVE_INFINITY
                else -> region2(T, p)[1] - h }
        }
        var pa = P_MIN; var pb = P_SAT_MAX
        ok(hAt(pa) < 0 && hAt(pb) > 0, "Punto (h, s) fuori dal campo supportato")
        repeat(60) { val m = 0.5 * (pa + pb); if (hAt(m) < 0) pa = m else pb = m }
        val p = 0.5 * (pa + pb); val T = tFromPS(p)
        ok(T > 0, "Punto (h, s) fuori dal campo supportato")
        val r = region2(T, p)
        return Stato(T, p, h, s, r[0], null, "Vapore surriscaldato")
    }

    private fun tSatOrMin(p: Double) = if (p <= P_SAT_MAX) tSat(p) else T_SAT_MAX
}
