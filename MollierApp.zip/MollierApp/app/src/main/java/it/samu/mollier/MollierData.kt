package it.samu.mollier

enum class Kind { DOME, XLINE, ISOBAR, ISOTHERM }

/** Una curva del diagramma: punti (s [kJ/kgK], h [kJ/kg]) e un'etichetta opzionale posta al punto labelIdx. */
class Curve(
    val s: DoubleArray, val h: DoubleArray, val kind: Kind,
    val label: String? = null, val labelIdx: Int = -1
)

/** Viewport del diagramma (coordinate fisiche). */
data class Viewport(val sMin: Double, val sMax: Double, val hMin: Double, val hMax: Double)

object MollierData {
    val DEFAULT_VIEW = Viewport(0.0, 11.5, 0.0, 4300.0)
    private val isobarsBar = doubleArrayOf(0.01, 0.05, 0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 160.0)
    private val isothermsC = doubleArrayOf(100.0, 150.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 600.0, 700.0, 800.0)

    private fun fmt(v: Double) = if (v == v.toInt().toDouble()) v.toInt().toString() else v.toString()

    fun build(): List<Curve> {
        val out = ArrayList<Curve>()

        // Griglia di temperature di saturazione
        val ts = ArrayList<Double>()
        var t = If97.T_MIN
        while (t < If97.T_SAT_MAX) { ts.add(t); t += 5.0 }
        ts.add(If97.T_SAT_MAX)
        val sat = ts.map { If97.sat(it) } // [p, vf, hf, sf, vg, hg, sg]

        // Campana: x = 0 e x = 1
        out.add(Curve(DoubleArray(sat.size) { sat[it][3] }, DoubleArray(sat.size) { sat[it][2] }, Kind.DOME))
        out.add(Curve(DoubleArray(sat.size) { sat[it][6] }, DoubleArray(sat.size) { sat[it][5] }, Kind.DOME))

        // Linee a titolo costante
        val lblIdx = ts.indexOfFirst { it >= 320.0 }
        for (i in 1..9) {
            val x = i / 10.0
            out.add(Curve(
                DoubleArray(sat.size) { sat[it][3] + x * (sat[it][6] - sat[it][3]) },
                DoubleArray(sat.size) { sat[it][2] + x * (sat[it][5] - sat[it][2]) },
                Kind.XLINE, "x=${fmt(x)}", lblIdx
            ))
        }

        // Isobare: tratto rettilineo nella campana + curva nel vapore surriscaldato
        for (bar in isobarsBar) {
            val p = bar / 10.0
            val tS = If97.tSat(p)
            val q = If97.sat(tS)
            val ss = arrayListOf(q[3], q[6]); val hh = arrayListOf(q[2], q[5])
            var lbl = 1
            var T = tS + 8.0
            while (T < If97.T_MAX) {
                val r = If97.region2(T, p); ss.add(r[2]); hh.add(r[1])
                if (T < 773.15) lbl = ss.size - 1
                T += 8.0
            }
            val r = If97.region2(If97.T_MAX, p); ss.add(r[2]); hh.add(r[1])
            out.add(Curve(ss.toDoubleArray(), hh.toDoubleArray(), Kind.ISOBAR, "${fmt(bar)} bar", lbl))
        }

        // Isoterme nel vapore surriscaldato (p da saturazione, o 16 MPa, fino a 0.001 MPa)
        for (tc in isothermsC) {
            val T = tc + 273.15
            val pHi = if (T <= If97.T_SAT_MAX) If97.pSat(T) else 16.0
            val pLo = 0.001
            if (pHi <= pLo) continue
            val n = 60
            val ss = DoubleArray(n); val hh = DoubleArray(n)
            for (i in 0 until n) {
                val p = pHi * Math.pow(pLo / pHi, i / (n - 1.0))
                val r = If97.region2(T, p); ss[i] = r[2]; hh[i] = r[1]
            }
            out.add(Curve(ss, hh, Kind.ISOTHERM, "${fmt(tc)}°C", n - 1))
        }
        return out
    }
}
