# Mollier – app Android (Kotlin + Jetpack Compose)

Calcolatore + diagramma h–s interattivo dell'acqua (IAPWS-IF97).

## Come ottenere l'APK
1. Installa Android Studio (Ladybug o successivo) e apri la cartella `MollierApp`.
2. Attendi il Gradle Sync (scarica Gradle 8.9 e le librerie; serve internet).
3. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. L'APK è in `app/build/outputs/apk/debug/app-debug.apk`: copialo sul telefono e installalo
   (abilita "Installa app da fonti sconosciute").

Da riga di comando (dopo aver aperto il progetto una volta con Android Studio): `gradle assembleDebug`.

## Modalità di input
- T, p   (°C, bar)  → liquido sottoraffreddato o vapore surriscaldato
- h, s   (kJ/kg, kJ/kgK) → T, p, titolo x, v
- T, x / p, x → stato di saturazione
Nel diagramma: trascina = sposta, pizzica = zoom, tocca = legge i valori del punto.

## Limiti
Regione 3 IF97 (T > 350 °C con liquido / zona critica) non implementata.
